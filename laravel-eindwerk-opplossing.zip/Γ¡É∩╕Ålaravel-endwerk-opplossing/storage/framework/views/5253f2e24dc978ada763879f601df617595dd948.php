
<div class="bg-white p-4 <?php if(session('discount')): ?> opacity-50 <?php endif; ?>">
    <h1 class="text-2xl font-semibold">Kortingscode</h1>
    <p class="text-gray-500 text-lg">Vul een kortingscode in om te genieten van extra voordelen</p>
    <form action="<?php echo e(route('discount.set')); ?>" method="post" class="mt-2 flex gap-4">
        <?php echo csrf_field(); ?>
        <input <?php if(session('discount')): ?> disabled <?php endif; ?> name="code" value="<?php echo e(old('code')); ?>" placeholder="Code" class="uppercase bg-white appearance-none px-4 py-2 border border-gray-500">
        <button type="submit" class="text-xl">
            <i class="fa-solid fa-circle-check"></i>
        </button>
    </form>
    <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH /var/www/html/resources/views/cart/includes/discount-code.blade.php ENDPATH**/ ?>