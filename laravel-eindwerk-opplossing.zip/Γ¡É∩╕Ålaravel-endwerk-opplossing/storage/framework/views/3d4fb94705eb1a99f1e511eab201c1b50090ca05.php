<header class="py-4 border-b border-gray-300 mb-8">
    <div class="container px-8 mx-auto flex justify-between items-center">
        <div class="text-xl flex gap-4 items-center">
            <a class="hover:text-orange-500" href="<?php echo e(route('products.index')); ?>">producten</a>
            
        </div>
        <div>
            <h1 class="text-2xl">
                <a href="<?php echo e(route('products.index')); ?>">
                    <span class="text-orange-500"><i class="fa-solid fa-shoe-prints"></i></span>
                    <span class="text-orange-500">Awesome</span> Shoestore
                </a>
            </h1>
        </div>
        <div class="flex gap-4 text-xl items-center">
            <a href="<?php echo e(route('profile')); ?>"><i class="fa-solid fa-user"></i></a>
            <a href="<?php echo e(route('favorites')); ?>"><i class="fa-solid fa-heart"></i></a>
            <a href="<?php echo e(route('cart')); ?>" class="bg-gray-200 px-4 py-1 rounded-full">
                <i class="fa-regular fa-cart-shopping"></i>
                <?php if(auth()->guard()->check()): ?>
                    <span><?php echo e(Auth::user()->cart_count); ?> items</span>
                <?php endif; ?>
            </a>
        </div>
    </div>
</header>
<?php /**PATH /var/www/html/resources/views/layouts/includes/header.blade.php ENDPATH**/ ?>