<?php $__env->startSection('title', $product->name . ' - ' . $product->description); ?>

<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-2 gap-x-24">
        <div>
            <img src="<?php echo e(asset('images/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>">
        </div>
        <div>
            <p>
                <a class="hover:underline text-2xl" href="<?php echo e(route('brands.show', $product->brand)); ?>"><?php echo e($product->brand->name); ?></a>
            </p>
            <h1 class="font-semibold text-4xl">
                <?php echo e($product->name); ?>

            </h1>
            <p class="text-gray-500"><?php echo e($product->description); ?></p>
            <p class="text-3xl mt-2">
                &euro;<?php echo e($product->price); ?>

            </p>

            <div class="mt-4">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt voluptatibus at consequatur dicta laborum, quasi voluptatum iste voluptate fuga commodi debitis voluptates, magnam non tenetur mollitia eaque ex ullam est?</p>
            </div>

            <?php echo $__env->make('store.includes.order-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('store.includes.shipping-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <div class="mt-24">
        <?php echo $__env->make('store.includes.related', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/store/show.blade.php ENDPATH**/ ?>