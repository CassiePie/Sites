<div class="flex gap-8 -mt-4 bg-gray-100 py-2 px-4">
    <a class="hover:underline" href="#">
        <i class="fa-solid fa-user-pen"></i>
        Update profile
    </a>
    <a class="hover:underline" href="#">
        <i class="fa-solid fa-heart"></i>
        Favorites
    </a>
    <a class="hover:underline" href="#">
        <i class="fa-solid fa-bag-shopping"></i>
        My orders
    </a>
    <a class="hover:underline" href="#">
        <i class="fa-solid fa-right-from-bracket"></i>
        Logout
    </a>
</div>
<?php /**PATH /var/www/html/resources/views/includes/user-menu.blade.php ENDPATH**/ ?>