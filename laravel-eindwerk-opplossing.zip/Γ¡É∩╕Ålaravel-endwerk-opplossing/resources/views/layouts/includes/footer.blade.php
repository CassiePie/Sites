<div class="bg-black text-white py-4 mt-24">
    <div class="container px-8 mx-auto flex gap-4">
        <a class="hover:underline" href="#">Privacy</a>
        <a class="hover:underline" href="#">Data security</a>
    </div>
</div>
